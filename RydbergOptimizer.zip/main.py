import core.configuration as config
import core.optimizer

if __name__ == '__main__':
    # Initialize Cell
    cell = config.Configuration()

    # Parameters
    nparticles = 100
    cellsize = 100
    moment = (1, 0, 0)

    # Initialize randomly:
    cell.makeRandom(nparticles, cellsize)

    # Initialize aligned:
    # cell.makeAligned(nparticles, cellsize, moment)

    # Plot dipoles & Write CSV
    cell.plotdipoles(fn='random')
    cell.write(fn='configuration_random.csv')

    # Initialize Optimizer
    optimizer = core.optimizer.Optimizer(maxit=1000)

    # Optimize Cell
    optcell = optimizer.optimize(cell)
    # Plot dipoles & write CSV
    optcell.plotdipoles(fn='optimal')
    optcell.write(fn='configuration_optimal.csv')
